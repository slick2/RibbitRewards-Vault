0.1.0 / 2012-12-24
==================

  * Adding component.json
