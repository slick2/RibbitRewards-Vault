/* Entry */
$(document).ready(function () {
    check(function () {
        if (verbose) console.log("done checking identity")
    })
}) 


/* Globals */
var bitcore, ECIES, explorers, insight, transaction, qrcode
var foundIdentity = {}
var check, lazyCheck, getDisplayName, checkLocalIdentity

/* Functions */
var preInit = function() {
	bitcore = require('bitcore')
    ECIES = require('bitcore-ecies')
    explorers = require('bitcore-explorers-multi')
			
			// $( function() {			
			// 	dd = $( '#cd-dropdown' ).dropdown();	
			// });
			// $( function() {				
			// 	$( '#cd-dropdown2' ).dropdown();	
			// });
			
			insight = new explorers.Insight("ribbit");
	        transaction = new bitcore.Transaction()
	        qrcode = new QRCode("qrcode");
    check = function(cb){
        Vault.getAddressesByPrivateKeyFormat("Extended Identity",function(keys){
            foundIdentity = keys
            return cb()
        })
    }
     
    lazyCheck = function(){
        setTimeout(function(){checkLocalIdentity() },5000) 
    }
    lazyCheck()
    getDisplayName = function(element) {
        Vault.getSettingValue("DisplayName",function(setting){
            if (setting !== undefined) {
                element.val(setting)
            }
        })
    }
    checkLocalIdentity = function(){
    	if (foundIdentity.length == 0) {
    		Vault.saveHDAddress(true,function(){
    			if (verbose) console.log("Created a new identity")
    			check(function(){ console.log("checked identity again")
                lazyCheck() })
    		})
    	} else {
    		if (verbose) console.log("Using identity address: "+foundIdentity[0].address.addressData)
    		$(".identity").html(foundIdentity[0].address.addressData)
    		$("#identityAddress").val(foundIdentity[0].address.addressData)
    		initVideo(foundIdentity[0].address.addressData)
    		joinIdentity()
    	}
    }
    explorers = require('bitcore-explorers-multi')
}

var initApplication = function(ident) {
	
}